package com.usuarios.usuarioApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsuarioAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsuarioAppApplication.class, args);
	}

}
